﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LongestPalindrome
{
    public class Program
    {
        static void Main(string[] args)
        {
            LongestPal longObj = new LongestPal();
            var output = longObj.GetLongestPalInaGivenString("abcbk");
            Console.WriteLine(output);
            Console.ReadLine();
        }
    }

    /*
       this is called dynamic programming
      //Time complexity: O(n^2)
      //Auxiliary complexity: O(n^2) 
    */
    public class LongestPal
    {
        public LongestPal()
        {
        }
        public string GetLongestPalInaGivenString(string input)
        {

            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }

            // All substrings of length 1 are palindromes

            int n = input.Length;
            bool[,] table = new bool[n, n];
            int maxLength = 1;
            for (int i = 0; i < n; ++i)
            {
                table[i, i] = true;
            }
            // check for sub-string of length 2.
            int start = 0;
            for (int i = 0; i < n - 1; ++i)
            {
                if (input[i] == input[i + 1])
                {
                    table[i, i + 1] = true;
                    start = i;
                    maxLength = 2;
                }
            }
            // Check for lengths greater than 2. k is length
            // of substring
            for (int k = 3; k <= n; ++k)
            {
                // Fix the starting index
                for (int i = 0; i < n - k + 1; ++i)
                {
                    // Get the ending index of substring from
                    // starting index i and length k
                    int j = i + k - 1;
                    // checking for sub-string from ith index to
                    // jth index iff str[i+1] to str[j-1] is a
                    // palindrome
                    if (table[i + 1, j - 1] && input[i] == input[j])
                    {
                        table[i, j] = true;
                        if (k > maxLength)
                        {
                            start = i;
                            maxLength = k;
                        }
                    }
                }
            }
            return input.Substring(start, maxLength);
        }
    }
}
